const NewTileData = [
 
    {
      img: '/static/images/grid-list/Sanju.jpg',
      title: 'Sanju',
      author: 'director90',
    },
    {
      img: '/static/images/grid-list/Avengers.jpg',
      title: 'Avengers',
      author: 'Danson67',
    },
    {
      img: '/static/images/grid-list/WW84.jpg',
      title: 'WW84',
      author: 'fancycrave1',
      featured: true,
    },
    {
      img: '/static/images/grid-list/Radhe.jpg',
      title: 'Radhe',
      author: 'Hans',
    },
    {
      img: '/static/images/grid-list/Thor.jpg',
      title: 'Thor',
      author: 'fancycravel',
    },
    {
      img: '/static/images/grid-list/Godzilla.jpg',
      title: 'Godzilla',
      author: 'jill111',
      cols: 2,
    },
    {
      img: '/static/images/grid-list/Joker.jpg',
      title: 'Joker',
      author: 'BkrmadtyaKarki',
    },
    {
      img: '/static/images/grid-list/mushroom.jpg',
      title: 'Mushrooms',
      author: 'PublicDomainPictures',
    },
    {
      img: '/static/images/grid-list/LaLaLand.jpg',
      title: 'La La Land',
      author: 'congerdesign',
    },
    {
      img: '/static/images/grid-list/StarWars.jpg',
      title: 'Star Wars',
      cols: 2,
      author: '821292',
    },
    {
      img: '/static/images/grid-list/BTS.jpg',
      title: 'BTS',
      author: 'danfador',
    },
  ];
  
  export default NewTileData;