import React from 'react';
import './UpcomingMovies.css';

const UpcomingMovies = function () {
    return (
        <div className="upcomingmovies">
            Upcoming Movies
        </div>
    )
}



export default UpcomingMovies;